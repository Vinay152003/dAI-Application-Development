from flask import Flask, jsonify, send_from_directory
from flask_swagger_ui import get_swaggerui_blueprint

app = Flask(__name__)

# Define a sample endpoint that returns a list of users
@app.route('/users', methods=['GET'])
def get_users():
    users = [
        {"id": 1, "name": "Alice"},
        {"id": 2, "name": "Bob"}
    ]
    return jsonify(users)

# Swagger UI configuration
SWAGGER_URL = '/swagger'  # The URL for accessing Swagger UI
API_URL = '/static/openapi.yaml'  # Path to the OpenAPI spec file

# Set up Swagger UI blueprint
swagger_ui_blueprint = get_swaggerui_blueprint(
    SWAGGER_URL,
    API_URL,
    config={'app_name': "Sample API"}
)

# Register Swagger UI blueprint with Flask
app.register_blueprint(swagger_ui_blueprint, url_prefix=SWAGGER_URL)

# Serve the OpenAPI spec file from the static folder
@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory('static', filename)

if __name__ == '__main__':
    app.run(debug=True)
