
import openai
from flask import Flask, request, jsonify

app = Flask(__name__)

# Set your OpenAI API key
openai.api_key = "sk-D9ixmJPkYRxNf6VocMpigKvgvgnEERYsil-H_TE924T3BlbkFJW_sN0RBonfmcCv-kfXCV3HriMfX39PNOZdct2UE0QA"

@app.route('/')
def home():
    return jsonify({
        "message": "Welcome to the Query Optimizer API!",
        "endpoints": {
            "/optimize_query": "POST - Analyze and optimize SQL queries"
        }
    })

@app.route('/optimize_query', methods=['POST'])
def optimize_query():
    data = request.json

    # Extract SQL query and schema from the request
    sql_query = data.get("query")
    schema = data.get("schema", "")

    if not sql_query:
        return jsonify({"error": "Query is required"}), 400

    # OpenAI API prompt for optimization
    prompt = f"""
    Database Schema: {schema if schema else "Schema not provided"}
    SQL Query: {sql_query}

    Analyze the query for performance issues, identify potential bottlenecks, and provide optimization suggestions. 
    Explain each suggestion clearly and include the impact on query performance.
    """

    try:
        # Call OpenAI API
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are an expert SQL query optimizer."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7
        )

        # Extract optimization suggestions
        suggestions = response['choices'][0]['message']['content']

        return jsonify({
            "query": sql_query,
            "schema": schema,
            "suggestions": suggestions
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True)
