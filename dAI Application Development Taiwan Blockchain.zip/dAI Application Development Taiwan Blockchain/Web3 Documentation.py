import openai
import os

# Configure OpenAI API Key
openai.api_key = os.getenv("sk-D9ixmJPkYRxNf6VocMpigKvgvgnEERYsil-H_TE924T3BlbkFJW_sN0RBonfmcCv-kfXCV3HriMfX39PNOZdct2UE0QA")

class Web3DocumentationTool:
    def __init__(self, project_files, metadata):
        self.project_files = project_files
        self.metadata = metadata
        self.documentation = ""

    def parse_project_files(self):
        # Parsing logic for smart contracts and metadata
        parsed_data = {"functions": [], "comments": [], "events": []}
        # Simulating parsed data
        parsed_data["functions"].append({"name": "mint", "description": "Mints a new NFT", "params": ["address to", "uint256 tokenId"]})
        return parsed_data

    def generate_api_reference(self, parsed_data):
        # Generating API reference using parsed data
        self.documentation += "### API Reference\n"
        for func in parsed_data["functions"]:
            self.documentation += f"**Function: {func['name']}**\n- **Description**: {func['description']}\n"
            self.documentation += f"- **Parameters**: {', '.join(func['params'])}\n"

    def refine_with_openai(self, content):
        # Use OpenAI API to refine documentation
        response = openai.Completion.create(
            engine="text-davinci-003",
            prompt=f"Improve this documentation content:\n\n{content}",
            max_tokens=200
        )
        return response.choices[0].text.strip()

    def generate_live_examples(self):
        # Embed live blockchain interaction examples
        examples = "### Examples\n```solidity\n// Minting an NFT\nMyNFT.mint(0x1234..., 1);\n```"
        return examples

    def advanced_search_and_indexing(self):
        # Simulate advanced search feature
        return {"index": ["mint", "transfer"], "search": "Results for 'mint'"}

    def generate_documentation(self):
        parsed_data = self.parse_project_files()
        self.generate_api_reference(parsed_data)
        
        # AI-enhanced documentation refinement
        self.documentation = self.refine_with_openai(self.documentation)

        # Add live examples
        self.documentation += "\n\n" + self.generate_live_examples()

        # Advanced search indexing (for demonstration)
        indexing = self.advanced_search_and_indexing()
        self.documentation += f"\n\n### Index:\n{indexing['index']}"

    def export_documentation(self, format="Markdown"):
        # Export documentation
        if format == "Markdown":
            with open("documentation.md", "w") as file:
                file.write(self.documentation)
        elif format == "HTML":
            with open("documentation.html", "w") as file:
                file.write(f"<html><body><pre>{self.documentation}</pre></body></html>")

# Example usage
project_files = ["MyNFT.sol"]
metadata = {"name": "MyDApp", "chain": "Ethereum"}
tool = Web3DocumentationTool(project_files, metadata)
tool.generate_documentation()
tool.export_documentation("Markdown")
