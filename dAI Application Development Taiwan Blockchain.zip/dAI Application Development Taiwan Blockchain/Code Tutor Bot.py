from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import openai
import subprocess
import tempfile

# Initialize FastAPI app
app = FastAPI()

# Configure OpenAI API Key
openai.api_key = "sk-D9ixmJPkYRxNf6VocMpigKvgvgnEERYsil-H_TE924T3BlbkFJW_sN0RBonfmcCv-kfXCV3HriMfX39PNOZdct2UE0QA"

# Models
class ExerciseRequest(BaseModel):
    skill_level: str
    topic: str

class CodeSubmission(BaseModel):
    code: str
    language: str
    prompt: str

class CodeExecutionRequest(BaseModel):
    code: str
    language: str
    inputs: str = ""  # Optional input for the program

# Routes
@app.post("/generate-exercise/")
async def generate_exercise(request: ExerciseRequest):
    """
    Generate a coding exercise dynamically using OpenAI.
    """
    prompt = (
        f"Generate a {request.skill_level} coding exercise on {request.topic}. "
        "Include a clear problem description, example input/output, and a sample solution."
    )
    try:
        response = openai.Completion.create(
            engine="gpt-4",
            prompt=prompt,
            max_tokens=500,
            temperature=0.7
        )
        return {"exercise": response.choices[0].text.strip()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/analyze-code/")
async def analyze_code(submission: CodeSubmission):
    """
    Analyze the user-submitted code and provide feedback using OpenAI.
    """
    feedback_prompt = (
        f"Analyze the following {submission.language} code and provide feedback:\n\n"
        f"Code:\n{submission.code}\n\nPrompt:\n{submission.prompt}"
    )
    try:
        response = openai.Completion.create(
            engine="gpt-4",
            prompt=feedback_prompt,
            max_tokens=300,
            temperature=0.7
        )
        return {"feedback": response.choices[0].text.strip()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/debug-code/")
async def debug_code(submission: CodeSubmission):
    """
    Debug user-submitted code and explain issues using OpenAI.
    """
    debug_prompt = (
        f"Debug the following {submission.language} code and explain any issues:\n\n"
        f"Code:\n{submission.code}"
    )
    try:
        response = openai.Completion.create(
            engine="gpt-4",
            prompt=debug_prompt,
            max_tokens=300,
            temperature=0.7
        )
        return {"debug": response.choices[0].text.strip()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/execute-code/")
async def execute_code(request: CodeExecutionRequest):
    """
    Execute code in a secure local sandbox environment.
    """
    language_commands = {
        "python": "python3",
        "javascript": "node",
        "java": "javac && java"
        # Add more language commands as needed
    }

    command = language_commands.get(request.language.lower())
    if not command:
        raise HTTPException(status_code=400, detail="Unsupported programming language.")

    try:
        with tempfile.NamedTemporaryFile(suffix=f".{request.language}", delete=False) as temp_code_file:
            temp_code_file.write(request.code.encode())
            temp_code_file_path = temp_code_file.name

        if request.language.lower() == "java":
            # Special handling for Java
            compile_process = subprocess.run(
                ["javac", temp_code_file_path],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
            )
            if compile_process.returncode != 0:
                raise HTTPException(status_code=400, detail=compile_process.stderr)
            temp_code_file_path = temp_code_file_path.replace(".java", "")
            run_process = subprocess.run(
                ["java", temp_code_file_path],
                input=request.inputs, text=True, capture_output=True
            )
        else:
            run_process = subprocess.run(
                [command, temp_code_file_path],
                input=request.inputs, text=True, capture_output=True
            )

        if run_process.returncode != 0:
            raise HTTPException(status_code=400, detail=run_process.stderr)

        return {"output": run_process.stdout}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if temp_code_file_path:
            subprocess.run(["rm", "-f", temp_code_file_path])

# Run the app (if running locally)
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
