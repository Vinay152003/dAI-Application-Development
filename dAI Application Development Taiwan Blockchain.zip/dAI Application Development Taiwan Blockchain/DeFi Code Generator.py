import openai

# Set your OpenAI API key
openai.api_key = 'sk-D9ixmJPkYRxNf6VocMpigKvgvgnEERYsil-H_TE924T3BlbkFJW_sN0RBonfmcCv-kfXCV3HriMfX39PNOZdct2UE0QA'

# Function to generate DeFi contract code using OpenAI API
def generate_defi_code(pattern, parameters):
    prompt = f"Generate a Solidity contract for {pattern} with the following parameters: {parameters}"
    
    try:
        response = openai.Completion.create(
            engine="text-davinci-003",  # You can use "gpt-4" if available
            prompt=prompt,
            max_tokens=500,
            temperature=0.5
        )
        return response.choices[0].text.strip()
    except Exception as e:
        return f"Error generating code: {e}"

# Function to create an ERC-20 token contract
def generate_erc20_token_contract(name, symbol, decimals, total_supply):
    pattern = "an ERC-20 token"
    parameters = f"Name '{name}', Symbol '{symbol}', Decimal Places '{decimals}', Total Supply '{total_supply}'"
    return generate_defi_code(pattern, parameters)

# Function to create a Staking contract
def generate_staking_contract(staking_token, reward_rate):
    pattern = "a staking contract"
    parameters = f"Staking Token '{staking_token}', Reward Rate '{reward_rate}'"
    return generate_defi_code(pattern, parameters)

# Function to create a Lending contract (simplified)
def generate_lending_contract(lending_token, interest_rate, duration):
    pattern = "a lending contract"
    parameters = f"Lending Token '{lending_token}', Interest Rate '{interest_rate}', Duration '{duration}'"
    return generate_defi_code(pattern, parameters)

# Main function to interact with the user
def main():
    print("Welcome to the DeFi Code Generator!")
    print("Choose a contract type:")
    print("1. ERC-20 Token")
    print("2. Staking Contract")
    print("3. Lending Contract")
    
    choice = input("Enter your choice (1/2/3): ").strip()
    
    if choice == "1":
        name = input("Enter token name: ").strip()
        symbol = input("Enter token symbol: ").strip()
        decimals = input("Enter decimal places: ").strip()
        total_supply = input("Enter total supply: ").strip()
        code = generate_erc20_token_contract(name, symbol, decimals, total_supply)
        
    elif choice == "2":
        staking_token = input("Enter staking token address: ").strip()
        reward_rate = input("Enter reward rate: ").strip()
        code = generate_staking_contract(staking_token, reward_rate)
        
    elif choice == "3":
        lending_token = input("Enter lending token address: ").strip()
        interest_rate = input("Enter interest rate: ").strip()
        duration = input("Enter loan duration: ").strip()
        code = generate_lending_contract(lending_token, interest_rate, duration)
        
    else:
        print("Invalid choice!")
        return
    
    print("\nGenerated Solidity Code:\n")
    print(code)

if __name__ == "__main__":
    main()
