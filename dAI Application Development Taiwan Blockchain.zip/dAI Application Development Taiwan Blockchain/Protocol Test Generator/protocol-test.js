const { expect } = require("chai");

describe("Token contract", function () {
  let Token, token, owner, addr1, addr2;

  beforeEach(async function () {
    Token = await ethers.getContractFactory("Token");
    [owner, addr1, addr2] = await ethers.getSigners();

    token = await Token.deploy();
    await token.deployed();
  });

  // Example test case from generated test suite
  it("Should transfer tokens between accounts", async function () {
    await token.transfer(addr1.address, 50);
    const addr1Balance = await token.balances(addr1.address);
    expect(addr1Balance).to.equal(50);
  });

  // Add more tests generated from OpenAI here
});
